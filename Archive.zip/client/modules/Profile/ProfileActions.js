import callApi from '../../util/apiCaller';
import localStorage from 'localStorage';
// Export Constants
export const ACTIONS = {
  TOGGLE_GOOGLE: 'TOGGLE_GOOGLE',
};
