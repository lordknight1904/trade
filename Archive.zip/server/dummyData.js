import Admin from './models/user';
export default function () {
}
